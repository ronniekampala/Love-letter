const audio=document.getElementById("bgMusic");
function startMusic(){
  if(audio){audio.volume=.35; audio.play().catch(()=>{});}
}
function toggleMusic(){
  if(!audio)return;
  if(audio.paused){audio.volume=.35;audio.play();document.getElementById("musicText").textContent="Pause";}
  else{audio.pause();document.getElementById("musicText").textContent="Play";}
}
window.addEventListener("load",()=>{
  if(audio){audio.volume=.35; audio.play().catch(()=>{});}
});
document.addEventListener("click",()=>{if(audio&&audio.paused){audio.volume=.35;audio.play().catch(()=>{});}}, {once:true});
